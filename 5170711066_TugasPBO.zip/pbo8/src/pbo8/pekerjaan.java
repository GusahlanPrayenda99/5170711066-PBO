
package pbo8;

public class pekerjaan extends manusia{
 void PNS(){
     System.out.println("Senin-Jumat 8 jam kerja");
 }
 }


