package pbo8;

public class manusia {
    protected void lakiLaki(){
        System.out.println("Tampan");
        System.out.println("Gagah");
        System.out.println("Hitam/putih");
        
            }
    protected void Perempuan(){
        System.out.println("Cantik");
        System.out.println("Seksi");
        System.out.println("Hitam/putih");
    }
    
}


