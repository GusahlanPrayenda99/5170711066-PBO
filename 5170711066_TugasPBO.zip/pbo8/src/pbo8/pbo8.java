package pbo8;

public class pbo8 {
 
public static void main(String[]args){   

manusia fisik = new manusia();
TingkahLaku kemampuan = new TingkahLaku();
pekerjaan usaha = new pekerjaan();

fisik.lakiLaki();
fisik.Perempuan();
kemampuan.Berjalan();
kemampuan.Melihat();
kemampuan.mendengar();
usaha.PNS();
}   
}

    
    

