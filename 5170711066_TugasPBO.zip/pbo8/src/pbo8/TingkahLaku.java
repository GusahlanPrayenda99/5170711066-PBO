package pbo8;
public class TingkahLaku extends manusia{
    public int mata;
    public int telinga;
    protected int kaki;
    
  public TingkahLaku(){
  mata = 2;
  kaki = 2;
  telinga = 2;
    }
    void Berjalan(){
        System.out.println("Manusia bergerak menggunakan ="+ kaki + " Kaki");
    }
    void Melihat(){
        System.out.println("Manusia Melihat Dengan ="+  mata +    " Mata");
    }
    void mendengar (){
        System.out.println("Manusia mendengar dengan="+ telinga  + " Telinga");
    }
}
   
